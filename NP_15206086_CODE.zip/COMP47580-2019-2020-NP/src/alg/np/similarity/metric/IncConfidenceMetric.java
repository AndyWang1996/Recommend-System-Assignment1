/**
 * Compute the similarity between two items based on increase in confidence
 */ 

package alg.np.similarity.metric;

import java.util.Set;

import org.omg.DynamicAny.NameDynAnyPair;

import profile.Profile;
import util.reader.DatasetReader;

public class IncConfidenceMetric implements SimilarityMetric
{
	private static double RATING_THRESHOLD = 4.0; // the threshold rating for liked items 
	private DatasetReader reader; // dataset reader

	/**
	 * constructor - creates a new IncConfidenceMetric object
	 * @param reader - dataset reader
	 */
	public IncConfidenceMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}

	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		// calculate similarity using conf(X => Y) / conf(!X => Y)
		Profile xProfile = reader.getItemProfiles().get(X);
		Profile yProfile = reader.getItemProfiles().get(Y);
		
		double cx = 0;
		double cnx = 0;
		double cxy = 0;
		double cnxy = 0;
		
		for (Integer k : xProfile.getIds()) 
		{
			if (xProfile.getValue(k) >= RATING_THRESHOLD) {cx += 1;}
			else {cnx += 1;}
		}
		
		Set<Integer> common = xProfile.getCommonIds(yProfile);
		
		for (Integer k : common) 
		{
			if (yProfile.getValue(k) >= RATING_THRESHOLD) 
			{
				if (xProfile.getValue(k) >= RATING_THRESHOLD){cxy += 1;}
				else {cnxy += 1;}
			}
			else {continue;}
		}
		
		int nx = xProfile.getSize();
		int nxy = xProfile.getSize() + yProfile.getSize() - common.size();
		if (nx == 0 || nxy == 0) 
		{
			return 0;
		}
		else 
		{
			double suppx = cx/nx;
			double suppnx = cnx/nx;
			double suppxy = cxy/nxy;
			double suppnxy = cnxy/nxy;
			if (suppx == 0 || suppnx == 0) 
			{
				return 0;
			}
			else 
			{
				double confxy = suppxy/suppx;
				double confnxy = suppnxy/suppnx;
				if (confnxy == 0) 
				{
					return 0;
				}
				else 
				{
					return confxy/confnxy;
				}
			}
		}
	}
}
