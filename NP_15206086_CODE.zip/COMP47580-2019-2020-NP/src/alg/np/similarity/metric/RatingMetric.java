/**
 * Compute the similarity between two items based on the Cosine between item ratings
 */ 

package alg.np.similarity.metric;

import java.util.Set;

import profile.Profile;
import util.reader.DatasetReader;

public class RatingMetric implements SimilarityMetric
{
	private DatasetReader reader; // dataset reader

	/**
	 * constructor - creates a new RatingMetric object
	 * @param reader - dataset reader
	 */
	public RatingMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}

	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		// calculate similarity using Cosine
		Profile XItem = reader.getItemProfiles().get(X);
		Profile YItem = reader.getItemProfiles().get(Y);
		Set<Integer> commonIntegers = XItem.getCommonIds(YItem);
		
		double upper = 0;
		double down = 0;
		
		down = XItem.getNorm() * YItem.getNorm();
		
		if(commonIntegers.size() != 0){
			 for(Integer k:commonIntegers) {
				upper += XItem.getValue(k)*YItem.getValue(k);
			 }
		 }
		 else {
			 return 0;
		 }
		
		 if (down != 0){
			return upper/down;
		 }
		 else{
			return 0;
		 }
	}
}
