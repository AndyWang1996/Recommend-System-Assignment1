/**
 * Compute the similarity between two items based on the Cosine between item genome scores
 */ 

package alg.np.similarity.metric;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import javafx.animation.PauseTransition;
import profile.Profile;
import util.reader.DatasetReader;

public class GenomeMetric implements SimilarityMetric
{
	private DatasetReader reader; // dataset reader
	
	/**
	 * constructor - creates a new GenomeMetric object
	 * @param reader - dataset reader
	 */
	public GenomeMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}
	
	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		// calculate similarity using weighted Jaccard
		 Profile Xgenome = reader.getItem(X).getGenomeScores();
		 Profile Ygenome = reader.getItem(Y).getGenomeScores();
		 
		 Set<Integer> IDcommon = Xgenome.getCommonIds(Ygenome);
		 
		 double min = 0;
		 double max = 0;
		 
		 if(IDcommon.size() != 0)
		 {
			 Iterator<Integer> it = IDcommon.iterator();
			 while (it.hasNext()) 
			 {
				int k = it.next();
				min += Math.min(Xgenome.getValue(k), Ygenome.getValue(k));
				max += Math.max(Xgenome.getValue(k), Ygenome.getValue(k));
			 }
			 if(max == 0) 
			 {
				 return 0;
			 }
			 else
			 {
				 return min/max;
			 }
		 }
		 else 
		 {
			 return 0;
		 }
//		 return 0;
	}
}
